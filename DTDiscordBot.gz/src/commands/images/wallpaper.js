const fetch = require("node-fetch")
module.exports = async (client, interaction, args) => {
    var images = []
    const query = interaction.options.getString('name');

    // Use FREE API 
    
}

